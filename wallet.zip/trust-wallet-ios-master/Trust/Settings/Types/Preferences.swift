// Copyright DApps Platform Inc. All rights reserved.

import Foundation

struct Preferences: Codable {
}
