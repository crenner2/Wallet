// Copyright DApps Platform Inc. All rights reserved.

import Foundation

enum SplashState {
    case new
    case error(SplashError)
}
