// Copyright DApps Platform Inc. All rights reserved.

import Foundation

struct DAppRequester {
    let title: String?
    let url: URL?
}
