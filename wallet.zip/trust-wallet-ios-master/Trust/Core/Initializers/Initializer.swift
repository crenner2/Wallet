// Copyright DApps Platform Inc. All rights reserved.

import Foundation

protocol Initializer {
    func perform()
}
