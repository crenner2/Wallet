// Copyright DApps Platform Inc. All rights reserved.

import Foundation

protocol JailbreakChecker {
    func isJailbroken() -> Bool
}
