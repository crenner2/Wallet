// Copyright DApps Platform Inc. All rights reserved.

import Foundation

struct TokenTransfer {
    let value: String
    let from: String
    let to: String
    let token: Token
}
