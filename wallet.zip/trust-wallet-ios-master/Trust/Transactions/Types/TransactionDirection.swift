// Copyright DApps Platform Inc. All rights reserved.

import Foundation

enum TransactionDirection {
    case incoming
    case outgoing
}
