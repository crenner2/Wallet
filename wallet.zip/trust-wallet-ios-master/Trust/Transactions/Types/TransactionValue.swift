// Copyright DApps Platform Inc. All rights reserved.

import Foundation

struct TransactionValue {
    let amount: String
    let symbol: String
}
