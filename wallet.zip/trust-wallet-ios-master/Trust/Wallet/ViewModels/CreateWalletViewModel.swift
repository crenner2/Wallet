// Copyright DApps Platform Inc. All rights reserved.

import Foundation
import UIKit

struct CreateWalletViewModel {

    var title: String {
        return "New Wallet"
    }
}
