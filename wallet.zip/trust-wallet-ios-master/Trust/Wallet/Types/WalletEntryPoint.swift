// Copyright DApps Platform Inc. All rights reserved.

import Foundation

enum WalletEntryPoint {
    case welcome
    case createInstantWallet
    case importWallet
}
