// Copyright DApps Platform Inc. All rights reserved.

import Foundation

enum DAppError: Error {
    case cancelled
}
