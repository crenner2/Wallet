// Copyright DApps Platform Inc. All rights reserved.

import Foundation

protocol Scrollable {
    func scrollOnTop()
}
