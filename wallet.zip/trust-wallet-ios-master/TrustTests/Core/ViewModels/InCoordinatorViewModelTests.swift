// Copyright DApps Platform Inc. All rights reserved.

import XCTest
@testable import Trust

class InCoordinatorViewModelTests: XCTestCase {

}
