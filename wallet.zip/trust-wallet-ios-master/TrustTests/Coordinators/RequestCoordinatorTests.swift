// Copyright DApps Platform Inc. All rights reserved.

import XCTest
@testable import Trust

class RequestCoordinatorTests: XCTestCase {

//    func testRootViewController() {
//        let coordinator = RequestCoordinator(
//            session: .make(),
//            token: .make()
//        )
//
//        XCTAssertTrue(coordinator.rootViewController is RequestViewController)
//    }
}

